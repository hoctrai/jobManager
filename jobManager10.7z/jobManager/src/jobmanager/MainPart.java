 
package jobmanager;


import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.GridData;

public class MainPart {
	
	private LeftComposite m_leftComposite;
	private RightComposite m_rightComposite;

	@Inject
	public MainPart(/*Shell shell*/) {
//		Display display = new Display();
//		Shell shell = new Shell();
		
		
		
//		shell.open();
//		while(!shell.isDisposed()){
//			if(!display.readAndDispatch())
//				display.sleep();
//		}
//		display.dispose();
//		
	}
	
	public LeftComposite getM_leftComposite() {
		return m_leftComposite;
	}

	public void setM_leftComposite(LeftComposite leftComposite) {
		this.m_leftComposite = null;
		this.m_leftComposite = leftComposite;
	}

	public RightComposite getM_rightComposite() {
		return m_rightComposite;
	}

	public void setM_rightComposite(RightComposite m_rightComposite) {
		this.m_rightComposite = null;
		this.m_rightComposite = m_rightComposite;
	}
	


	@PostConstruct
	public void postConstruct(Composite parent) {
		
//		parent.setLayout(new GridLayout(2, false));
//		
//		MenuComposite menuComposite = new MenuComposite(parent, SWT.NONE);
//		GridData gd_menuComposite = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
//		gd_menuComposite.widthHint = 184;
//		menuComposite.setLayoutData(gd_menuComposite);
//		new Label(parent, SWT.NONE);
//		
//		
//		
//		m_leftComposite = new LeftComposite(parent, SWT.NONE);
//		GridData gd_leftComposite = new GridData(GridData.FILL_VERTICAL);
//		gd_leftComposite.heightHint = 354;
//		gd_leftComposite.widthHint = 181;
//		m_leftComposite.setLayoutData(gd_leftComposite);
//		
//		
//		m_rightComposite = new RightComposite(parent, SWT.NONE);
//		GridData gd_rightComposite = new GridData(GridData.FILL_VERTICAL);
//		gd_rightComposite.heightHint = 417;
//		//gd_rightComposite.heightHint = 393;
//		gd_rightComposite.widthHint = 458;
//		m_rightComposite.setLayoutData(gd_rightComposite);
//		
//
//		getTreeNodeChoose(m_leftComposite);
//		getWindownShow(m_rightComposite);
//		
//	}
//
//	private void getTreeNodeChoose(LeftComposite leftComposite) {
//		leftComposite.populateControl();
//	}
//	
//	private void getWindownShow(RightComposite rightComposite){
//		rightComposite.windowExecute();
	}
}