 
package jobmanager1;

import javax.inject.Inject;

import javax.annotation.PostConstruct;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;

public class MainPart {
	public LeftComposite leftComposite;
	
	public LeftComposite getLeftComposite() {
		return leftComposite;
	}




	public void setLeftComposite(LeftComposite leftComposite) {
		this.leftComposite = leftComposite;
	}

	@Inject
	public MainPart() {
		
	}

	@PostConstruct
	public void postConstruct(Composite parent) {
		parent.setLayout(new GridLayout(1, false));
		
		leftComposite = new LeftComposite(parent, SWT.NONE);
		GridData gd_leftComposite = new GridData(GridData.FILL_VERTICAL);
		gd_leftComposite.widthHint = 181;
		leftComposite.setLayoutData(gd_leftComposite);
		
		getTreeNodeChoose(leftComposite);
	}

	private void getTreeNodeChoose(LeftComposite leftComposite) {
		leftComposite.populateControl();
	}
}