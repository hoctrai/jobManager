package jobmanager1;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class OpenHandler {
	@Execute
	public void execute(Shell  shell){
		
		//Composite parent = new Composite(shell, SWT.NONE);
//		MainPart mainPart = new MainPart();
//		mainPart.postConstruct(parent);
		//mainPart.postConstruct(parent);
		
//		leftComposite.populateControl();
		Update update =new Update();
		
		
		
	}
}
