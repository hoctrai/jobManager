package jobmanager1;

import java.util.ArrayList;
import java.util.List;

public class TreeNode {
	private String name;
	private String strParameters;
	private List<TreeNode> children = new ArrayList<TreeNode>();
	private TreeNode parent;
	
	public TreeNode(String name) {
		this.name = name;
		this.strParameters = "";
	}


	public String getStrParameters() {
		return strParameters;
	}
	
	public void setStrParameters(String strParameters) {
		this.strParameters = strParameters;
	}
	
	public Object getParent() {
		  return parent;
	}
	
	public void setParent(TreeNode treeNode) {
		this.parent = treeNode;
	}
	
	public TreeNode addChild(TreeNode child) {
		children.add(child);
		child.parent = this;
		return this;
	}
	
	public List<TreeNode> getChildren() {
		return children;
	}
	
	public String toString() {
		return name;
	}
}
