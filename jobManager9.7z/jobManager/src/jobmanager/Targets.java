package jobmanager;



public class Targets {
	
	
	
}
