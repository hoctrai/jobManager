package jobmanager;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;


public class RightComposite extends Composite {
	private Table m_table;
	private Text m_text;
	List<TableItem> m_item = new ArrayList<>();
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public RightComposite(Composite parent, int style) {
		super(parent, style);
		//windowExecute(getShell());
	}
	
	
//	public Text getText() {
//		return text;
//	}
//
//	
//	public void setText(String text) {
//		
//		this.text.setText(text);
//	}

	public void gridText(){
		
	}
	
	public void windowExecute(Shell shell){
		
		setLayout(new GridLayout(1, false));
		
		m_table = new Table(this, SWT.BORDER | SWT.FULL_SELECTION);
		GridData gd_table = new GridData(GridData.FILL_HORIZONTAL);
		gd_table.heightHint = 68;
		m_table.setLayoutData(gd_table);
		m_table.setHeaderVisible(true);
		m_table.setLinesVisible(true);
		
//		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
//		GridData gd_table = new GridData(GridData.FILL_BOTH);
//		//gd_table.widthHint = 236;
//		table.setLayoutData(gd_table);
		
//		table.setHeaderVisible(true);
//		table.setLinesVisible(true);
		
		TableColumn columnName = new TableColumn(m_table, SWT.CENTER);
		columnName.setWidth(50);
		columnName.setText("Name");
		
		TableColumn columnCategory = new TableColumn(m_table, SWT.CENTER);
		columnCategory.setWidth(87);
		columnCategory.setText("Category Job");
		
		TableColumn columnIdJob = new TableColumn(m_table, SWT.CENTER);
		columnIdJob.setWidth(50);
		columnIdJob.setText("Id Job");
		
		TableColumn columnJobType = new TableColumn(m_table, SWT.CENTER);
		columnJobType.setWidth(65);
		columnJobType.setText("Job Type");
		
		TableColumn columnSubmitTime = new TableColumn(m_table, SWT.CENTER);
		columnSubmitTime.setWidth(90);
		columnSubmitTime.setText("Submit Time");
		
		TableColumn columnStartTime = new TableColumn(m_table, SWT.CENTER);
		columnStartTime.setWidth(81);
		columnStartTime.setText("Start Time");
		
		TableColumn columnTimeOut = new TableColumn(m_table, SWT.CENTER);
		columnTimeOut.setWidth(77);
		columnTimeOut.setText("Time Out");
		
		TableColumn columnServer = new TableColumn(m_table, SWT.CENTER);
		columnServer.setWidth(70);
		columnServer.setText("Server");
		
		m_text = new Text(this, SWT.BORDER | SWT.MULTI | SWT.WRAP | SWT.V_SCROLL);
		GridData gd_text = new GridData(GridData.FILL_BOTH);
		gd_text.heightHint = 200;
		m_text.setLayoutData(gd_text);
		m_item.add( new TableItem(m_table, SWT.NONE));
		m_item.add( new TableItem(m_table, SWT.NONE));
		
		
	}
	/*-------------------------------------------------------------------------------------------------------------*/
	
	public void showDataTarget(Target target){
		
		Planned planned;
		Started started;
		int n;
		String s = target.getName();
		String NameTarget =  s.substring(4,s.length()-5);
		String nameCategory="", id="", type="";
		String submit="", start="", timeout="", server="";
		
		for (int i = 0; i<target.getListCategoryJobs().size(); i++){
			s = target.getListCategoryJobs().get(i).m_name;
			//n=;
			if((n=target.getListCategoryJobs().get(i).getPlanned().getStrPlan().size())>0){
				
				planned = target.getListCategoryJobs().get(i).getPlanned();
				nameCategory = s.substring(4, s.length()-5);
				for(int j = 0; j <n; j++){
					s= planned.getStrPlan().get(j);
					String[] strParent = s.split(",");
					String[] strChild = strParent[0].split(":");
					id = strChild [0];
					type = strChild[2];
					
					for(int k = 1; k < strParent.length; k++){
						Optional<String> opt = Optional.ofNullable(strParent[k]);
						
						if(submit.equals(""))
							submit = opt.filter(x->x.contains("submitTime")).get().replaceAll("submitTime", "");
						else if(start.equals(""))
							start = opt.filter(x->x.contains("start")).get().replaceAll("startTime","");
						else if(timeout.equals(""))
							timeout = opt.filter(x->x.contains("timeout")).get().replaceAll("timeout:","");
						else if(server.equals(""))
							server = opt.filter(x->x.contains("Server")).get().replaceAll("Server:", "");
						
					}
					m_item.get(j).setText(new String[] {NameTarget,nameCategory, id, type,  submit, start, timeout, server});
					if(n<2)
						m_item.get(1).setText(new String[] {"", "", "", "", "", "", "", ""});
				}
				
			}
			if((n=target.getListCategoryJobs().get(i).getStared().getStrStarter().size())>0){
				started = target.getListCategoryJobs().get(i).getStared();
				nameCategory = s.substring(4, s.length()-5);
				for(int j = 0; j <n; j++){
					s= started.getStrStarter().get(j);
					String[] strParent = s.split(",");
					String[] strChild = strParent[0].split(":");
					id = strChild [0];
					type = strChild[2];
					
					for(int k = 1; k < strParent.length; k++){
						Optional<String> opt = Optional.ofNullable(strParent[k]);
						
						if(submit.equals(""))
							submit = opt.filter(x->x.contains("submitTime")).get().replaceAll("submitTime", "");
						else if(start.equals(""))
							start = opt.filter(x->x.contains("start")).get().replaceAll("startTime","");
						else if(timeout.equals(""))
							timeout = opt.filter(x->x.contains("timeout")).get().replaceAll("timeout:","");
						else if(server.equals(""))
							server = opt.filter(x->x.contains("Server")).get().replaceAll("Server:", "");
						
					}
					m_item.get(j).setText(new String[] {NameTarget, nameCategory, id, type, submit, start, timeout, server});
					if(n<2)
						m_item.get(1).setText(new String[] {"", "", "", "", "", "", "", ""});
				}
				
			}
		}
	}
	
	public void showRunTarget(Target target){
		
		String strPlanned1 = "<h3>Moved to worker pool</h3>";
		String strPlanned2 = "<h3>Execution started by worker thread</h3>";
		int n;
		String nameTarget = target.getName();
		String str = nameTarget ;
		
		for(int i = 0; i < target.getListCategoryJobs().size(); i++ ){
			String nameCategory = target.getListCategoryJobs().get(i).getName();
			String namePlan = target.getListCategoryJobs().get(i).getPlanned().getNamePlan();
			str = str + "\n" + nameCategory + "\n" + namePlan;
			//**************************************************************/
			n = target.getListCategoryJobs().get(i).getPlanned().getStrPlan().size();
			
			for(int j = 0; j < n; j++){
				String planned = target.getListCategoryJobs().get(i).getPlanned().getStrPlan().get(i);
				str = str + "\n" + planned;
			}
			str = str +  "\n" + strPlanned1;
			n = target.getListCategoryJobs().get(i).getOngoing().getStrOngoing().size();
			for(int j = 0; j < n; j++)
				str = str + "\n" + target.getListCategoryJobs().get(i).getOngoing().getStrOngoing().get(j);
			str = str + "\n" + strPlanned2;
			n = target.getListCategoryJobs().get(i).getStared().getStrStarter().size();
			for(int j = 0; j < n; j++)
				str = str + "\n" + target.getListCategoryJobs().get(i).getStared().getStrStarter().get(j);
			
			
		}
		String strJobPerFamily = "<h2>Executing jobs per Family</h2>";
		str = str + "\n" + strJobPerFamily +"\n"+ target.getJobsPerJobFamily();
		
		//System.out.println(str);
		m_text.setText(str);
	}
	

	@Override
	protected void checkSubclass() {
		
	}
}
