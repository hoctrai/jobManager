package jobmanager;


import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;

public class LeftComposite extends Composite {
	TreeNode m_root;
	
	//FilterPlanned filterPlanned  = new FilterPlanned(getShell());
	FilterFree filterFree = new FilterFree();
	FilterPlanned filterPlanned = new FilterPlanned();
	FilterWorkedPool filterWorkedPool =new FilterWorkedPool();
	FilterExecutionWorker filterExecutionWorker = new FilterExecutionWorker();
	TreeCategory treeCategory = new TreeCategory();
	
	TreeViewer m_viewer;
	
//	TabFolder tabFolder =  new TabFolder(this, SWT.NONE); ;
//	TabItem[] tabItem = new TabItem[4];
//	String[] filterName = {"Free","Planned","Pool","Excution"};
	//TreeViewer[] m_viewer = new TreeViewer[4];
	
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	
	public LeftComposite(Composite parent, int style){
		super(parent, style);
		//populateControl();
	}
	
	public void populateControl() {
	    FillLayout compositeLayout = new FillLayout();
	    setLayout(compositeLayout);
	    
	    //tabFolder.setBounds(10, 0, 121, 43);
	    GridData gd_tabFolder = new GridData(GridData.FILL_VERTICAL);
	    
	   // m_viewer = new TreeViewer(this,0);
	    //filterFree.createTreeViewer(m_viewer, getShell());
	    
	   
		//for(int i = 0; i < m_viewer.length ; i++){
			m_viewer = new TreeViewer(this,0);
			
		
//		}
	 }
	
	public void getFilter(String string){
		if(string.equals("open"))
			filterFree.createTreeViewer(m_viewer, getShell());
		
		else if(string.equals(""))
			m_viewer.setInput(filterFree.m_root);
		else if(string.equals("Planned"))
			filterPlanned.createTreeViewer(m_viewer, filterFree);
		
		else if(string.equals("Execution"))
			filterExecutionWorker.createTreeViewer(m_viewer, filterFree);
		
		else if(string.equals("Worked Pool"))
			filterWorkedPool.createTreeViewer(m_viewer, filterFree);
		

//		tabItem[0].setControl(filterFree.createTreeViewer(m_viewer[0],getShell()).getControl());
//		
//		tabItem[1].setControl(filterPlanned.createTreeViewer(m_viewer[1],filterFree).getControl());
//		
//		tabItem[2].setControl(filterWorkedPool.createTreeViewer(m_viewer[2],filterFree).getControl());
//		
//		//tabItem[3].setControl(filterExecutionWorker.createTreeViewer(m_viewer[3],filterFree).getControl());
//		
//		
//		 tabFolder.setSize(400, 200);
		 
	}
	
	public void getTreeCategory(String string){
		
		if(string.equals("open")){
			treeCategory.treeCategory(filterFree.m_root);
		}
		else{
			treeCategory.createTreeViewer(m_viewer, string);
			System.out.println("LeftComposite:  row:  92");
		}
	}
	
	
	
	
}

