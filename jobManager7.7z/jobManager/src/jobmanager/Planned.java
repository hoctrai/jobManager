package jobmanager;

public class Planned {
	private String stringPlan;
	public Planned() {
		this.stringPlan = "";
		
	}
	
	public String getStringPlan() {
		return stringPlan;
	}
	
	public void setStringPlan(String stringPlan) {
		this.stringPlan = stringPlan;
	}
	
}
