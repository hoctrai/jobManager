package jobmanager;


import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class MainClass {
	private LeftComposite m_leftComposite;
	private RightComposite m_rightComposite;
	//TreeViewer m_viewer;
	static MainClass m_mainClass = new MainClass();
	static MenuMain m_menuMain = new MenuMain();
	
	private Target m_target;

	public MainClass() {

	}
	
	public void clickNode(){
		
		m_leftComposite.m_viewer.addSelectionChangedListener(new ISelectionChangedListener() {
			
			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				if(event.getSelection() instanceof IStructuredSelection) {
					
					//System.out.println(m_target.toString());
					try{
						IStructuredSelection selection = (IStructuredSelection) event.getSelection();
						String strTarget = selection.getFirstElement().toString();
						FindObject(strTarget);
						m_rightComposite.showDataTarget(m_target);
						
						
						//m_rightComposite.setText(m_target.toString());
					}catch (Exception e) {
						
					}
					
					
				}
				
			}
		});
		
	}
	
	public void clickOpen(){
		m_menuMain.openItem.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateLeftComposite();
			
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	
/*------------------------------------------*/
	
	public void updateRightComposite(String text){
		
		//m_mainClass.m_rightComposite.setText(text);
		
		
	}
	
	public void updateLeftComposite(){
		try{
		m_mainClass.m_leftComposite.createTreeViewer();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	

	
	public void FindObject(String strTarget){
		
		try{
			String targetName;
			
			for(int i = 0 ; i < m_mainClass.m_leftComposite.m_root.getChildren().size() ; i++ ){
				targetName = m_mainClass.m_leftComposite.m_root.getChildren().get(i).getTarget().getName();
//				System.out.println("1.		"+targetName.substring(4, targetName.length()-5));
//				System.out.println("2.		"+strTarget);
				if(strTarget.equals(targetName.substring(4, targetName.length()-5))){
					
					//m_target = null;
					m_target = m_mainClass.m_leftComposite.m_root.getChildren().get(i).getTarget();
					updateRightComposite(m_target.toString());
					//System.out.println(m_target.toString());
					
					break;
				}
			
			}
			
			//m_mainClass.updateRightComposite(strTarget);
		}catch(Exception e){
		}
	}

/*------------------------------------------*/
	public static void main(String[] arg){
		
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setSize(690, 319);
		shell.setLayout(new GridLayout(2, false));
		
		/* call menu */
		
		
		m_menuMain.menu(shell);
		
		m_mainClass.m_leftComposite = new LeftComposite(shell, SWT.NONE);

		
		GridData gd_leftComposite = new GridData(GridData.FILL_VERTICAL);
		gd_leftComposite.widthHint = 138;
		gd_leftComposite.heightHint = 447;
		
		m_mainClass.m_leftComposite.setLayoutData(gd_leftComposite);
		m_mainClass.m_leftComposite.populateControl();
		
		m_mainClass.m_rightComposite = new RightComposite(shell, SWT.NONE);
		GridData gd_rightComposite = new GridData(GridData.FILL_BOTH);
		gd_rightComposite.heightHint = 400;
		m_mainClass.m_rightComposite.setLayoutData(gd_rightComposite);
		
		
		//m_mainClass.m_rightComposite.windowExecute(shell);
		
		m_mainClass.clickOpen();
		m_mainClass.clickNode();
		
		
		shell.open();
		while (!shell.isDisposed()) {
			if(!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
		
		
		
		
 
	}
}
