package jobmanager;

public class Started {
	private String stringStarter;
	public Started() {
		this.stringStarter = "";
		
	}
	
	public String getStringStarter() {
		return stringStarter;
	}
	
	public void setStringStarter(String stringStarter) {
		this.stringStarter = stringStarter;
	}
}
