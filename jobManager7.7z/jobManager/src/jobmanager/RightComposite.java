package jobmanager;

import java.awt.List;
import java.util.Optional;

import javax.print.attribute.standard.Severity;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;


public class RightComposite extends Composite {
	private Table table;
	private Table table_1;
	private Text text;
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public RightComposite(Composite parent, int style) {
		super(parent, style);
		
		windowExecute(parent.getShell());
		
	}
	
	
//	public Text getText() {
//		return text;
//	}
//
//	
//	public void setText(String text) {
//		
//		this.text.setText(text);
//	}

	public void gridText(){
		
	}
	
	public void windowExecute(Shell shell){
		
		setLayout(new GridLayout(1, false));
		
		table = new Table(this, SWT.BORDER | SWT.FULL_SELECTION);
		GridData gd_table = new GridData(GridData.FILL_HORIZONTAL);
		gd_table.heightHint = 68;
		table.setLayoutData(gd_table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
//		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
//		GridData gd_table = new GridData(GridData.FILL_BOTH);
//		//gd_table.widthHint = 236;
//		table.setLayoutData(gd_table);
		
//		table.setHeaderVisible(true);
//		table.setLinesVisible(true);
		
		TableColumn columnName = new TableColumn(table, SWT.CENTER);
		columnName.setWidth(50);
		columnName.setText("Name");
		
		TableColumn columnCategory = new TableColumn(table, SWT.CENTER);
		columnCategory.setWidth(87);
		columnCategory.setText("Category Job");
		
		TableColumn columnIdJob = new TableColumn(table, SWT.CENTER);
		columnIdJob.setWidth(50);
		columnIdJob.setText("Id Job");
		
		TableColumn columnJobType = new TableColumn(table, SWT.CENTER);
		columnJobType.setWidth(65);
		columnJobType.setText("Job Type");
		
		TableColumn columnSubmitTime = new TableColumn(table, SWT.CENTER);
		columnSubmitTime.setWidth(90);
		columnSubmitTime.setText("Submit Time");
		
		TableColumn columnStartTime = new TableColumn(table, SWT.CENTER);
		columnStartTime.setWidth(81);
		columnStartTime.setText("Start Time");
		
		TableColumn columnTimeOut = new TableColumn(table, SWT.CENTER);
		columnTimeOut.setWidth(77);
		columnTimeOut.setText("Time Out");
		
		TableColumn columnServer = new TableColumn(table, SWT.CENTER);
		columnServer.setWidth(70);
		columnServer.setText("Server");
		
		text = new Text(this, SWT.BORDER);
		GridData gd_text = new GridData(GridData.FILL_BOTH);
		gd_text.heightHint = 200;
		text.setLayoutData(gd_text);
		
		
		
		
		
		
	}
	
	public void showDataTarget(Target target){
		
		Planned planned;
		String s = target.getName();
		String NameTarget =  s.substring(4,s.length()-5);
		String nameCategory="", id="", type="";
		String submit="", start="", timeout="", server="";
		//System.out.println("	"+NameTarget+"    "+ target.getListCategoryJobs().size());
		for (int i = 0; i<target.getListCategoryJobs().size(); i++){
			s = target.getListCategoryJobs().get(i).m_name;
			System.out.println("dfdlaskf "+ s );
			if(target.getListCategoryJobs().get(i).getPlanned().getStringPlan()!=""){
				planned = target.getListCategoryJobs().get(i).getPlanned();
				nameCategory = s.substring(4, s.length()-5);
				
				s = planned.getStringPlan();
				String[] strParent = s.split(",");
				String[] strchild = strParent[0].split(":"); 
				id = strchild[0];
				type = strchild[2];
				
				for(int j = 1; j< strParent.length; j++){
					Optional<String> opt = Optional.ofNullable(strParent[j]);
					
					if(submit.equals(""))
						submit = opt.filter(x->x.contains("submitTime")).get().replaceAll("submitTime", "");
					else if(start.equals(""))
						start = opt.filter(x->x.contains("start")).get().replaceAll("startTime","");
					else if(timeout.equals(""))
						timeout = opt.filter(x->x.contains("timeout")).get().replaceAll("timeout:","");
					else if(server.equals(""))
						server = opt.filter(x->x.contains("Server")).get().replaceAll("Server:", "");
					
				}
				
				
			}
			
		}
		//System.out.println(NameTarget+nameCategory+submit + start +timeout+server);
		
		TableItem item = new TableItem(table, SWT.NONE);
		item.setText(new String[] {NameTarget, id, type, nameCategory, submit, start, timeout, server});
	}
	
	
	

	@Override
	protected void checkSubclass() {
		
	}
}
