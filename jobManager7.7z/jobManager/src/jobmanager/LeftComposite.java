package jobmanager;

//import java.util.ArrayList;
//import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

//import java.util.EvenObject;
//import com.jobManager.TreeNode;

public class LeftComposite extends Composite {
	//int A=10;
	TreeNode m_root;
	TreeViewer m_viewer = new TreeViewer(this,0);

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	
	public LeftComposite(Composite parent, int style){
		super(parent, style);
		//populateControl();
	}
	
	public void populateControl() {
	    FillLayout compositeLayout = new FillLayout();
	    setLayout(compositeLayout);
	    
	    
	    
//	    int[] selectionStyle = { SWT.NONE };
//////	    System.out.println("selectionStyle:			"+selectionStyle.length);
////	    for (int selection = 0; selection < selectionStyle.length; selection++) {
//	    	int style = selectionStyle[0] ;//| checkStyle[check];
//	    	System.out.println("Style "+style);
//	    	//m_viewer = 
	    	createTreeViewer();
	    //}
	  }
	
	public TreeViewer createTreeViewer() {
		// TODO Auto-generated method stub
		//TreeViewer viewer = new TreeViewer(this, style);
		
		m_viewer.setContentProvider(new ITreeContentProvider() {
		public Object[] getChildren(Object parentElement) {
			return ((TreeNode) parentElement).getChildren().toArray();
		}
		public Object getParent(Object element) {
	    	return ((TreeNode) element).getParent();
		}

		public boolean hasChildren(Object element) {
			return ((TreeNode) element).getChildren().size() > 0;
		}

		public Object[] getElements(Object inputElement) {
			return ((TreeNode) inputElement).getChildren().toArray();
		}

		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
	      }
	    });
		  
		m_viewer.setInput(getRootNode());
		
		  
		return m_viewer;
		
	}

	
	
	OpenFile openFile = new OpenFile();
	private TreeNode getRootNode(){
		
		//String root = "root";
		m_root = new TreeNode("rootNode");
		openFile.diagogOpenFile(getShell());
		if(openFile.getM_path()!=null){
			m_root = openFile.getTargets();
			//openFile.addBranch(m_root);
			}
		System.out.println(m_root.getParent());
		
		return m_root;
	}
	public TreeViewer getViewer(){
		return (m_viewer == null) ? null : m_viewer;
	}
	public void deleteTree(){
		m_root.getChildren().clear();
		
	
	}
	
}

