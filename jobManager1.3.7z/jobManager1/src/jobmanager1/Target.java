package jobmanager1;

import java.util.ArrayList;
import java.util.List;

public class Target {
	private int  m_id;
	private String m_name;
	//private List <String> m_string=new ArrayList<>();
	
	public int getM_id() {
		return m_id;
	}
	public void setM_id(int m_id) {
		this.m_id = m_id;
	}
	
	public String getName() {
		return m_name;
	}
	public void setName() {
		this.m_name = "target: " +m_id;
	}
	public void setName(String name){
		this.m_name = name;
	}

//	public List<String> getM_string() {
//		return m_string;
//	}
//	public void setM_string(String string) {
//		this.m_string.add(string);
//	}
//	
	
	class Categoryjob{
		String name;
		String planned;
		String ongoing;
		String stared;
		/*--------*/
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPlanned() {
			return planned;
		}
		public void setPlanned(String planned) {
			this.planned = planned;
		}
		public String getOngoing() {
			return ongoing;
		}
		public void setOngoing(String ongoing) {
			this.ongoing = ongoing;
		}
		public String getStared() {
			return stared;
		}
		public void setStared(String stared) {
			this.stared = stared;
		}
	}
}
