package jobmanager1;

import java.util.ArrayList;
import java.util.List;

public class Targets {
	
	
	
}
