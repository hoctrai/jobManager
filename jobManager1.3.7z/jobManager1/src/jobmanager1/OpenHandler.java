package jobmanager1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.osgi.container.SystemModule;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;

public class OpenHandler {
	private String m_path;
	private Queue<String> m_stringQueue;
	private FileInputStream m_in;
	private BufferedReader m_inp;
	private TreeNode m_targets;
	
	@Execute
	public void execute(Shell  shell){
		FileDialog dialog= new FileDialog(shell);
		 m_path=dialog.open();
		 readFile();
	}
	
	
	public String getM_path() {
		return m_path;
	}
	
	public Queue getStringQueue() {
		return m_stringQueue;
	}
	
	/*Read file return value Node*/
	public void readFile(){
		String line;
		m_stringQueue = new LinkedList();
		try {
			 m_in = new FileInputStream(getM_path());
			 m_inp = new BufferedReader(new InputStreamReader(m_in));
			try {
				m_targets = new TreeNode("Targets: ");
				while((line = m_inp.readLine()) != null){
					addQueue(line);
					
					m_targets.addChild(Branch());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*add Strings in tail of Queue*/
	public void addQueue (String line){
		while(!line.equals("")){
			m_stringQueue.add(line);
			try {
				line = m_inp.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**Convert from Queue to Tree
	 * Model is:
	 * 	<h1>...</h1>
	 * 		<h2>...</h2>
	 * 			<h3>...</h3>
	 * 		<h2>...</h2>
	 *			<h3>...</h3>*/
	public TreeNode Branch () {
		TreeNode parent = null,firstChild = null,secondChild = null;
		while(!m_stringQueue.isEmpty()){
			
			if(m_stringQueue.peek().substring(0, 4).equals("<h1>")) {
				parent = new TreeNode(m_stringQueue.peek().substring(4, m_stringQueue.peek().length()-5));
				m_stringQueue.remove();
				
			}else if(m_stringQueue.peek().substring(0, 4).equals("<h2>")) {
				
				if(parent!=null){
					firstChild = new TreeNode(m_stringQueue.peek().substring(4, m_stringQueue.peek().length()-5));
					parent.addChild(firstChild);
					
				}else{
					parent = new TreeNode(m_stringQueue.peek().substring(4, m_stringQueue.peek().length()-5));
				}
				
				m_stringQueue.remove();
				
			}else if(m_stringQueue.peek().substring(0, 4).equals("<h3>")&&firstChild!=null) {
				secondChild = new TreeNode(m_stringQueue.peek().substring(4, m_stringQueue.peek().length()-5));
				firstChild.addChild(secondChild);
				m_stringQueue.remove();
				
			}else {
				if(firstChild == null){
					parent.setStrParameters(m_stringQueue.peek());
					m_stringQueue.remove();
				
				}else if(secondChild == null){
					firstChild.setStrParameters(m_stringQueue.peek());
					m_stringQueue.remove();
				
				}else {
					secondChild.setStrParameters(m_stringQueue.peek());
					m_stringQueue.remove();
				}
			}
		}
		return parent;
		
	}
	/*add branch in root of main Tree*/
	public void addBranch(TreeNode root ){
		//TreeNode parent = Branch();
		root.addChild(m_targets);
	}
}



