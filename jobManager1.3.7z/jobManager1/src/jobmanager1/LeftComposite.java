package jobmanager1;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

//import com.jobManager.TreeNode;

public class LeftComposite extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public LeftComposite(Composite parent, int style){
		super(parent, style);
		//populateControl();
	}
	public void populateControl() {
	    FillLayout compositeLayout = new FillLayout();
	    setLayout(compositeLayout);

	    int[] selectionStyle = { SWT.NONE };
//	    System.out.println("selectionStyle:			"+selectionStyle.length);
	    for (int selection = 0; selection < selectionStyle.length; selection++) {
	    	int style = selectionStyle[selection] ;//| checkStyle[check];
	        createTreeViewer(style);
	    }
	  }
	private void createTreeViewer(int style) {
		// TODO Auto-generated method stub
		TreeViewer viewer = new TreeViewer(this, style);

		  viewer.setContentProvider(new ITreeContentProvider() {
	      public Object[] getChildren(Object parentElement) {
	    	  return ((TreeNode) parentElement).getChildren().toArray();
	      }

	      public Object getParent(Object element) {
	    	  return ((TreeNode) element).getParent();
	      }

	      public boolean hasChildren(Object element) {
	    	  return ((TreeNode) element).getChildren().size() > 0;
	      }

	      public Object[] getElements(Object inputElement) {
	    	  return ((TreeNode) inputElement).getChildren().toArray();
	      }

	      public void dispose() {
	      }

	      public void inputChanged(Viewer viewer, Object oldInput,
	    		  Object newInput) {
	      }
	    });

		  viewer.setInput(getRootNode());
		
	}
	/*----------------------------------------------------------------------*/
	OpenHandler openHandler = new OpenHandler();

	
	private TreeNode getRootNode(){
		
		/*
		 *TreeNode target = new TreeNode("Target: ");
		 *root.addChild(target);
		 *openHandler = new OpenHandler();
		 *TreeNode branch = openHandler.Branch(openHandler.readFile());
		 *TreeNode branch = new TreeNode("branch");
		 *TreeNode aaa = new TreeNode("bbb");
		 *aaa.addChild(new TreeNode("ccc")).addChild(new TreeNode("ddd"));
		 *branch.addChild(aaa);
		 *root.addChild(branch); */

		TreeNode root = new TreeNode("root");
		openHandler.execute(getShell());
		openHandler.addBranch(root);

		return root;
	}
}
class TreeNode {
	
	private String name;
	private String strParameters;
	private List<TreeNode> children = new ArrayList<TreeNode>();
	private TreeNode parent;
	
	public TreeNode(String name) {
		this.name = name;
		this.strParameters = "";
	}


	public String getStrParameters() {
		return strParameters;
	}
	
	public void setStrParameters(String strParameters) {
		this.strParameters = strParameters;
	}
	
	public Object getParent() {
		  return parent;
	}
	
	public void setParent(TreeNode treeNode) {
		this.parent = treeNode;
	}
	
	public TreeNode addChild(TreeNode child) {
		children.add(child);
		child.parent = this;
		return this;
	}
	
	public List<TreeNode> getChildren() {
		return children;
	}
	
	public String toString() {
		return name;
	}



}
	
