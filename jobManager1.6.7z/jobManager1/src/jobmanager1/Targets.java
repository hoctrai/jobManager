package jobmanager1;



public class Targets {
	
	
	
}
