package jobmanager1;

//import java.util.ArrayList;
//import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

//import com.jobManager.TreeNode;

public class LeftComposite extends Composite {
	TreeNode m_root;
	

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	
	public LeftComposite(Composite parent, int style){
		super(parent, style);
		//populateControl();
	}
	public void populateControl() {
	    FillLayout compositeLayout = new FillLayout();
	    setLayout(compositeLayout);
	    
	    System.out.println("3333333333333333333333333333333333333333");
	    
	    int[] selectionStyle = { SWT.NONE };
////	    System.out.println("selectionStyle:			"+selectionStyle.length);
//	    for (int selection = 0; selection < selectionStyle.length; selection++) {
	    	int style = selectionStyle[0] ;//| checkStyle[check];
	        createTreeViewer(style);
	    //}
	  }
	private void createTreeViewer(int style) {
		// TODO Auto-generated method stub
		TreeViewer viewer = new TreeViewer(this, style);

		  viewer.setContentProvider(new ITreeContentProvider() {
	      public Object[] getChildren(Object parentElement) {
	    	  return ((TreeNode) parentElement).getChildren().toArray();
	      }

	      public Object getParent(Object element) {
	    	  return ((TreeNode) element).getParent();
	      }

	      public boolean hasChildren(Object element) {
	    	  return ((TreeNode) element).getChildren().size() > 0;
	      }

	      public Object[] getElements(Object inputElement) {
	    	  return ((TreeNode) inputElement).getChildren().toArray();
	      }

	      public void dispose() {
	      }

	      public void inputChanged(Viewer viewer, Object oldInput,
	    		  Object newInput) {
	      }
	    });
		  System.out.println("44444444444444444444444444444444444444444444");
		  //deleteTree(root);
		  viewer.setInput(getRootNode());
		
	}
	/**------------------------------*/
//	
	/*----------------------------------------------------------------------*/
	
	OpenFile openFile = new OpenFile();
	private TreeNode getRootNode(){
		
		m_root = new TreeNode("root");
		openFile.diagogOpenFile(getShell());
		if(openFile.getM_path()!=null){
			System.out.println("44444444444444444444444444455555555555555555");
			openFile.addBranch(m_root);}
		System.out.println("55555555555555555555555555555555555555555555555");
		System.out.println(m_root.getParent());
		return m_root;
	}
	
	public void deleteTree(){
		m_root.getChildren().clear();
		
	
	}
}




/*--------------------------------------------*
 * 
 * 
 * */

//public void populateControl(TreeNode target) {
//    FillLayout compositeLayout = new FillLayout();
//    setLayout(compositeLayout);
//
//    int[] selectionStyle = { SWT.NONE };
//////    System.out.println("selectionStyle:			"+selectionStyle.length);
////    for (int selection = 0; selection < selectionStyle.length; selection++) {
//    	int style = selectionStyle[0] ;//| checkStyle[check];
//        createTreeViewer(style,target);
//    //}
//  }
//private void createTreeViewer(int style,TreeNode target) {
//	// TODO Auto-generated method stub
//	TreeViewer viewer = new TreeViewer(this, style);
//
//	  viewer.setContentProvider(new ITreeContentProvider() {
//      public Object[] getChildren(Object parentElement) {
//    	  return ((TreeNode) parentElement).getChildren().toArray();
//      }
//
//      public Object getParent(Object element) {
//    	  return ((TreeNode) element).getParent();
//      }
//
//      public boolean hasChildren(Object element) {
//    	  return ((TreeNode) element).getChildren().size() > 0;
//      }
//
//      public Object[] getElements(Object inputElement) {
//    	  return ((TreeNode) inputElement).getChildren().toArray();
//      }
//
//      public void dispose() {
//      }
//
//      public void inputChanged(Viewer viewer, Object oldInput,
//    		  Object newInput) {
//      }
//    });
//
//	  viewer.setInput(getRootNode(target));
//	
//}
//
//
//
//private TreeNode getRootNode(TreeNode target ){
//	TreeNode root = new TreeNode("root");
//	root.addChild(target);
//	
//	return root;
//	
//}
 

	
