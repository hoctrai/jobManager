package jobmanager1;

import org.eclipse.swt.widgets.Composite;

import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;


public class RightComposite extends Composite {
	private Text text;
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public RightComposite(Composite parent, int style) {
		super(parent, style);
		
	}
	public void windowExecute(){

		setLayout(new GridLayout(1, false));
		text = new Text(this, SWT.MULTI | SWT.BORDER | SWT.WRAP | SWT.V_SCROLL);
		GridData gd_text = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_text.widthHint = 413;
		gd_text.heightHint = 397;
		text.setLayoutData(gd_text);
		text.setBounds(10, 10, 430, 280);
		
	}
	
	
	

	@Override
	protected void checkSubclass() {
		
	}
}
