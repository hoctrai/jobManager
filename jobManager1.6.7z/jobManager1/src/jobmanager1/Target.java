package jobmanager1;

import java.util.ArrayList;
import java.util.List;

public class Target {
	
	//private int  m_id;
	private String m_name;
	private List<CategoryJob> listCategoryJobs;
	//private List <String> m_string=new ArrayList<>();
	
	public Target(String name) {
		this.m_name = name;
		listCategoryJobs = new ArrayList<>();
	}
	
	public String getName() {
		return m_name;
	}
	public void setName(String name){
		this.m_name = name;
	}
	
	
	public void addListCategoryJobs(CategoryJob categoryJob){
		listCategoryJobs.add(categoryJob);
	}
	
	public List<CategoryJob> getListCategoryJobs() {
		return listCategoryJobs;
	}
	
	public void setListCategoryJobs(List<CategoryJob> listCategoryJobs) {
		this.listCategoryJobs = listCategoryJobs;
	}

//	public List<String> getM_string() {
//		return m_string;
//	}
//	public void setM_string(String string) {
//		this.m_string.add(string);
//	}
	
}
