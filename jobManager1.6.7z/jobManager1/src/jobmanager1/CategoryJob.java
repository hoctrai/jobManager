package jobmanager1;

public class CategoryJob{
	String m_name;
	Planned m_planned;
	Ongoing m_ongoing;
	Started m_stared;
	/*--------*/
	public CategoryJob(String name) {
		this.m_name = name;
		this.m_planned = null;
		this.m_ongoing = null;
		this.m_stared = null;
	}
	public String getName() {
		return m_name;
	}
	public void setName(String name) {
		this.m_name = name;
	}
	public Planned getM_planned() {
		return m_planned;
	}
	public void setM_planned(Planned m_planned) {
		this.m_planned = m_planned;
	}
	public Ongoing getM_ongoing() {
		return m_ongoing;
	}
	public void setM_ongoing(Ongoing m_ongoing) {
		this.m_ongoing = m_ongoing;
	}
	public Started getM_stared() {
		return m_stared;
	}
	public void setM_started(Started m_stared) {
		this.m_stared = m_stared;
	}
	
}
