package jobmanager1;

public class Ongoing {
	private String stringOngoing;
	public Ongoing() {
		this.stringOngoing = "";
	}
	
	public String getStringOngoing() {
		return stringOngoing;
	}
	
	public void setStringOngoing(String stringOngoing) {
		this.stringOngoing = stringOngoing;
	}
}
