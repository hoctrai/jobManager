package jobmanager1;

import javax.annotation.PostConstruct;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class OpenHandler {
//	Composite parent;
//	LeftComposite m_leftComposite;
//	MainPart m_mainPart;
	public OpenHandler() {
		
	}
	public void createMain(){
		//System.out.println("1111111111111111111111111111111");
		
//		Shell shell = new Shell();
//		shell.setLayout(new GridLayout(1, false));
//		parent = new Composite(shell, SWT.BORDER);
//		
//		m_mainPart = new MainPart();
//		m_mainPart.postConstruct(parent);
		//mainPart.setM_leftComposite(m_leftComposite);
	}
	
	@Execute
	public void execute(){
//		m_leftComposite = new LeftComposite(parent, SWT.NONE);
//		m_leftComposite.populateControl();
//		m_mainPart.setM_leftComposite(m_leftComposite);
	}
	public static void main(String[] arg){
		
		MainPart m_mainPart = new MainPart();
		
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		Composite parent = new Composite(shell, SWT.BORDER);
		
		
		m_mainPart.postConstruct(parent);
		
		shell.open();
		while (!shell.isDisposed()) {
			if(!display.readAndDispatch())
				display.sleep();
			
		}
		display.dispose();
	}
	
}
