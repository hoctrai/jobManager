package com.tma.jobmanager.tree;

import java.util.ArrayList;
import java.util.List;

import com.tma.jobmanager.target.CategoryJob;
import com.tma.jobmanager.target.Target;

public class FilterExecutionWorker {
	List<String> m_categoryJobs = new ArrayList<>();
	private TreeNode m_root = new TreeNode("root");
	
	public FilterExecutionWorker(){
		
	}
	
	public TreeNode filter(TreeNode root) {
		TreeNode node = new TreeNode("");
		try {
			for (int i = 0; i < root.getChildren().size() - 1; i++) {
				Target target = root.getChildren().get(i).getTarget();
				
				List<CategoryJob> listCategoryJobs = target.getListCategoryJobs();
				for (int j = 0; j < listCategoryJobs.size() ; j++) {
					
					CategoryJob categoryJob = listCategoryJobs.get(j);
					if (categoryJob.getStared().getStrStarter().size() > 0) {
						node = root.getChildren().get(i);
						this.m_root.addChild(node);
						break;
					}
				}
			}
		}catch (Exception e) {
			
		}
		return m_root;
	}

	public TreeNode getRoot() {
		return m_root;
	}

	public TreeNode getM_root() {
		return m_root;
	}

	public void setM_root(TreeNode m_root) {
		this.m_root = m_root;
	}
	
}
