package com.tma.jobmanager.tree;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.TreeViewer;

import com.tma.jobmanager.target.CategoryJob;

public class FilterWorkedPool {
	TreeViewer viewer;
	TreeNode m_root = new TreeNode("root");
	List<String> m_categoryJobs = new ArrayList<String>();
	
	public FilterWorkedPool(){
		
	}
	
	public TreeNode filter(TreeNode root) {
		
		TreeNode node = new TreeNode("");
		try{
			for(int i = 0; i < root.getChildren().size()-1; i++) {
				
				int n = root.getChildren().get(i).getTarget().getListCategoryJobs().size();
				if(n > 0) {
					for(int j = 0; j < n; j++) {
						
						CategoryJob categoryJob = root.getChildren().get(i).getTarget()
								.getListCategoryJobs().get(j);
						if(categoryJob.getOngoing().getStrOngoing().size()>0) {
							node = root.getChildren().get(i);
							this.m_root.addChild(node);
						}
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return m_root;
		
	}

	public TreeNode getRoot() {
		return m_root;
	}
	
	
}
