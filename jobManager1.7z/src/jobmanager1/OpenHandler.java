package jobmanager1;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class OpenHandler {
	private String m_path;
	@Execute
	public void execute(Shell  shell){
		FileDialog dialog= new FileDialog(shell);
		 m_path=dialog.open();
//		 System.out.println("path1:		   "+m_path);
//		 //link(parent,style);
//		 contF.setm_text(m_path);
//		 System.out.println("path2:				   "+m_path);
//		 //return m_cont;
	}
}

