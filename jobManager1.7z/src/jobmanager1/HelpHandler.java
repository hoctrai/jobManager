package jobmanager1;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.ui.workbench.IWorkbench;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class HelpHandler {
	@Execute
	public void execute(Shell shell ,IWorkbench workbench){
		if(MessageDialog.openConfirm(shell, "Help", "why must I help you?????")){
			workbench.close();
		}
	}
	

}
